package com.rizzbeats.gui;

import com.rizzbeats.audio.MusicPlayerManager;
import com.rizzbeats.config.RizzConfig;
import com.rizzbeats.fx.HitSoundManager;
import com.rizzbeats.fx.SoundPreset;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class RizzBeatsScreen extends Screen {
    private enum Tab { MUSIC, HIT_FX, KNOCK_FX }

    private Tab activeTab = Tab.MUSIC;
    private TextFieldWidget musicInputField;
    private TextFieldWidget knockKeywordsField;

    public RizzBeatsScreen() {
        super(Text.literal("RizzBeats & HitFX"));
    }

    @Override
    protected void init() {
        super.init();
        int centerX = this.width / 2;
        int top = 36;

        // Top Navigation Tabs
        addDrawableChild(ButtonWidget.builder(Text.literal("♪ Music & Lirik"), b -> switchTab(Tab.MUSIC))
            .dimensions(centerX - 155, top, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("⚔ Hit / Shoot FX"), b -> switchTab(Tab.HIT_FX))
            .dimensions(centerX - 50, top, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("★ RizzCity Knock"), b -> switchTab(Tab.KNOCK_FX))
            .dimensions(centerX + 55, top, 105, 20).build());

        if (activeTab == Tab.MUSIC) {
            buildMusicTab(centerX, top + 34);
        } else if (activeTab == Tab.HIT_FX) {
            buildHitFxTab(centerX, top + 34);
        } else {
            buildKnockFxTab(centerX, top + 34);
        }

        // Done / Close button
        addDrawableChild(ButtonWidget.builder(Text.literal("Simpan & Tutup"), b -> close())
            .dimensions(centerX - 60, this.height - 32, 120, 20).build());
    }

    private void switchTab(Tab nextTab) {
        saveFields();
        this.activeTab = nextTab;
        this.clearChildren();
        this.init();
    }

    private void buildMusicTab(int centerX, int y) {
        RizzConfig cfg = RizzConfig.get();

        musicInputField = new TextFieldWidget(this.textRenderer, centerX - 150, y, 225, 20, Text.literal("Nama lagu / Link"));
        musicInputField.setMaxLength(512);
        musicInputField.setPlaceholder(Text.literal("Ketik judul lagu atau paste link..."));
        addDrawableChild(musicInputField);

        addDrawableChild(ButtonWidget.builder(Text.literal("▶ Play"), b -> {
            String q = musicInputField.getText();
            if (!q.isBlank()) {
                MusicPlayerManager.getInstance().playFromInput(q);
            }
        }).dimensions(centerX + 80, y, 70, 20).build());

        // Playback Controls Row
        int row2 = y + 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("⏮ Prev"), b -> MusicPlayerManager.getInstance().previousTrack())
            .dimensions(centerX - 150, row2, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("⏯ Pause"), b -> MusicPlayerManager.getInstance().togglePause())
            .dimensions(centerX - 75, row2, 75, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("⏹ Stop"), b -> MusicPlayerManager.getInstance().stop())
            .dimensions(centerX + 5, row2, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("⏭ Next"), b -> MusicPlayerManager.getInstance().nextTrack())
            .dimensions(centerX + 80, row2, 70, 20).build());

        // Music Volume Slider
        int row3 = row2 + 28;
        addDrawableChild(new FloatSlider(centerX - 150, row3, 300, 20, "Volume Musik", cfg.musicVolume, 0.0f, 1.0f, val -> {
            MusicPlayerManager.getInstance().setVolume(val);
        }));

        // Lyrics HUD Toggle
        int row4 = row3 + 28;
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Lirik Atas Layar: " + (cfg.showLyricsHud ? "ON" : "OFF")),
            b -> {
                cfg.showLyricsHud = !cfg.showLyricsHud;
                RizzConfig.save();
                b.setMessage(Text.literal("Lirik Atas Layar: " + (cfg.showLyricsHud ? "ON" : "OFF")));
            }
        ).dimensions(centerX - 150, row4, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(
            Text.literal("Preview Baris Next: " + (cfg.showNextLyricLine ? "ON" : "OFF")),
            b -> {
                cfg.showNextLyricLine = !cfg.showNextLyricLine;
                RizzConfig.save();
                b.setMessage(Text.literal("Preview Baris Next: " + (cfg.showNextLyricLine ? "ON" : "OFF")));
            }
        ).dimensions(centerX + 5, row4, 145, 20).build());
    }

    private void buildHitFxTab(int centerX, int y) {
        RizzConfig cfg = RizzConfig.get();

        addDrawableChild(ButtonWidget.builder(
            Text.literal("Hit/Shoot Sound: " + (cfg.hitSoundEnabled ? "ON" : "OFF")),
            b -> {
                cfg.hitSoundEnabled = !cfg.hitSoundEnabled;
                RizzConfig.save();
                b.setMessage(Text.literal("Hit/Shoot Sound: " + (cfg.hitSoundEnabled ? "ON" : "OFF")));
            }
        ).dimensions(centerX - 150, y, 145, 20).build());

        addDrawableChild(ButtonWidget.builder(
            Text.literal("Hanya Player: " + (cfg.hitPlayersOnly ? "ON" : "OFF")),
            b -> {
                cfg.hitPlayersOnly = !cfg.hitPlayersOnly;
                RizzConfig.save();
                b.setMessage(Text.literal("Hanya Player: " + (cfg.hitPlayersOnly ? "ON" : "OFF")));
            }
        ).dimensions(centerX + 5, y, 145, 20).build());

        int row2 = y + 28;
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Pilihan Suara: " + cfg.getHitPreset().getDisplayName()),
            b -> {
                SoundPreset next = cfg.getHitPreset().next();
                cfg.hitSoundPreset = next.name();
                RizzConfig.save();
                b.setMessage(Text.literal("Pilihan Suara: " + next.getDisplayName()));
                HitSoundManager.playTestHitSound();
            }
        ).dimensions(centerX - 150, row2, 225, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("▶ Test"), b -> HitSoundManager.playTestHitSound())
            .dimensions(centerX + 80, row2, 70, 20).build());

        int row3 = row2 + 28;
        addDrawableChild(new FloatSlider(centerX - 150, row3, 145, 20, "Volume", cfg.hitSoundVolume, 0.0f, 1.5f, val -> {
            cfg.hitSoundVolume = val;
            RizzConfig.save();
        }));
        addDrawableChild(new FloatSlider(centerX + 5, row3, 145, 20, "Pitch", cfg.hitSoundPitch, 0.5f, 2.0f, val -> {
            cfg.hitSoundPitch = val;
            RizzConfig.save();
        }));
    }

    private void buildKnockFxTab(int centerX, int y) {
        RizzConfig cfg = RizzConfig.get();

        addDrawableChild(ButtonWidget.builder(
            Text.literal("RizzCity Knock 'Done' FX: " + (cfg.knockSoundEnabled ? "ON" : "OFF")),
            b -> {
                cfg.knockSoundEnabled = !cfg.knockSoundEnabled;
                RizzConfig.save();
                b.setMessage(Text.literal("RizzCity Knock 'Done' FX: " + (cfg.knockSoundEnabled ? "ON" : "OFF")));
            }
        ).dimensions(centerX - 150, y, 300, 20).build());

        int row2 = y + 28;
        addDrawableChild(ButtonWidget.builder(
            Text.literal("Suara Done: " + cfg.getKnockPreset().getDisplayName()),
            b -> {
                SoundPreset next = cfg.getKnockPreset().next();
                cfg.knockSoundPreset = next.name();
                RizzConfig.save();
                b.setMessage(Text.literal("Suara Done: " + next.getDisplayName()));
                HitSoundManager.playDoneSound();
            }
        ).dimensions(centerX - 150, row2, 225, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("▶ Test"), b -> HitSoundManager.playDoneSound())
            .dimensions(centerX + 80, row2, 70, 20).build());

        int row3 = row2 + 28;
        addDrawableChild(new FloatSlider(centerX - 150, row3, 145, 20, "Volume", cfg.knockSoundVolume, 0.0f, 1.5f, val -> {
            cfg.knockSoundVolume = val;
            RizzConfig.save();
        }));
        addDrawableChild(new FloatSlider(centerX + 5, row3, 145, 20, "Pitch", cfg.knockSoundPitch, 0.5f, 2.0f, val -> {
            cfg.knockSoundPitch = val;
            RizzConfig.save();
        }));

        int row4 = row3 + 36;
        knockKeywordsField = new TextFieldWidget(this.textRenderer, centerX - 150, row4, 300, 20, Text.literal("Keyword Knock"));
        knockKeywordsField.setMaxLength(300);
        knockKeywordsField.setText(cfg.knockKeywords);
        addDrawableChild(knockKeywordsField);
    }

    private void saveFields() {
        if (knockKeywordsField != null) {
            RizzConfig.get().knockKeywords = knockKeywordsField.getText();
            RizzConfig.save();
        }
    }

    @Override
    public void close() {
        saveFields();
        RizzConfig.save();
        super.close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int centerX = this.width / 2;

        context.drawCenteredTextWithShadow(this.textRenderer, "§b§lRizzBeats & HitFX §7(Fabric 1.21.8 - 1.21.11)", centerX, 14, 0xFFFFFF);

        if (activeTab == Tab.MUSIC) {
            MusicPlayerManager pm = MusicPlayerManager.getInstance();
            context.drawCenteredTextWithShadow(
                this.textRenderer,
                "§eNow Playing: §f" + pm.getCurrentTitle(),
                centerX, 194, 0xFFFFFF
            );
            context.drawCenteredTextWithShadow(
                this.textRenderer,
                "§7Status: §a" + pm.getStatusText() + "  §8|  §7Keybinds dapat diatur di Options -> Controls",
                centerX, 208, 0xAAAAAA
            );
        } else if (activeTab == Tab.KNOCK_FX) {
            context.drawTextWithShadow(
                this.textRenderer,
                "§7Kata kunci deteksi knock RizzCity (pisahkan dengan koma):",
                centerX - 150, 154, 0xCCCCCC
            );
        }
    }

    private static class FloatSlider extends SliderWidget {
        private final String label;
        private final float min;
        private final float max;
        private final java.util.function.Consumer<Float> onChange;

        public FloatSlider(int x, int y, int width, int height, String label, float current, float min, float max, java.util.function.Consumer<Float> onChange) {
            super(x, y, width, height, Text.empty(), (current - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.onChange = onChange;
            updateMessage();
        }

        private float getScaled() {
            return (float) (min + this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            int pct = Math.round(getScaled() * 100);
            this.setMessage(Text.literal(label + ": " + pct + "%"));
        }

        @Override
        protected void applyValue() {
            onChange.accept(getScaled());
        }
    }
}
