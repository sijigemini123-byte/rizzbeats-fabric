package com.rizzbeats.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rizzbeats.RizzBeatsClient;
import com.rizzbeats.fx.SoundPreset;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RizzConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("rizzbeats");
    public static final Path CONFIG_FILE = CONFIG_DIR.resolve("config.json");
    public static final Path CUSTOM_MUSIC_DIR = CONFIG_DIR.resolve("music");
    public static final Path CUSTOM_SOUNDS_DIR = CONFIG_DIR.resolve("sounds");

    private static RizzConfig INSTANCE = new RizzConfig();

    // Music & Lyrics Settings
    public float musicVolume = 0.70f;
    public boolean showLyricsHud = true;
    public boolean showNextLyricLine = true;
    public int lyricsTopY = 6;
    public List<String> recentQueries = new ArrayList<>();

    // Hit / Shoot Sound FX Settings
    public boolean hitSoundEnabled = true;
    public boolean hitPlayersOnly = false;
    public String hitSoundPreset = SoundPreset.PLING_HITMARKER.name();
    public float hitSoundVolume = 0.85f;
    public float hitSoundPitch = 1.25f;

    // RizzCity Knock ("Done") Sound FX Settings
    public boolean knockSoundEnabled = true;
    public String knockSoundPreset = SoundPreset.LEVEL_UP_DONE.name();
    public float knockSoundVolume = 1.0f;
    public float knockSoundPitch = 1.15f;
    public String knockKeywords = "knock,knocked,menjatuhkan,pingsan,tumbang,downed,eliminated";

    public static RizzConfig get() {
        return INSTANCE;
    }

    public static void load() {
        try {
            Files.createDirectories(CONFIG_DIR);
            Files.createDirectories(CUSTOM_MUSIC_DIR);
            Files.createDirectories(CUSTOM_SOUNDS_DIR);

            if (Files.exists(CONFIG_FILE)) {
                String json = Files.readString(CONFIG_FILE);
                RizzConfig loaded = GSON.fromJson(json, RizzConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                }
            } else {
                save();
            }
        } catch (IOException e) {
            RizzBeatsClient.LOGGER.error("Failed to load RizzBeats config", e);
        }
    }

    public static void save() {
        try {
            Files.createDirectories(CONFIG_DIR);
            Files.writeString(CONFIG_FILE, GSON.toJson(INSTANCE));
        } catch (IOException e) {
            RizzBeatsClient.LOGGER.error("Failed to save RizzBeats config", e);
        }
    }

    public SoundPreset getHitPreset() {
        return SoundPreset.fromName(hitSoundPreset, SoundPreset.PLING_HITMARKER);
    }

    public SoundPreset getKnockPreset() {
        return SoundPreset.fromName(knockSoundPreset, SoundPreset.LEVEL_UP_DONE);
    }

    public List<String> getKnockKeywordList() {
        if (knockKeywords == null || knockKeywords.isBlank()) {
            return List.of();
        }
        return Arrays.stream(knockKeywords.split(","))
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .map(String::toLowerCase)
            .toList();
    }
}
