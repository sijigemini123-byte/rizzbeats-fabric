package com.rizzbeats.mixin;

import com.rizzbeats.fx.KnockDetector;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudTitleMixin {
    @Inject(method = "setTitle", at = @At("HEAD"))
    private void rizzbeats$onSetTitle(Text title, CallbackInfo ci) {
        if (title != null) {
            KnockDetector.inspectMessage(title.getString());
        }
    }

    @Inject(method = "setSubtitle", at = @At("HEAD"))
    private void rizzbeats$onSetSubtitle(Text subtitle, CallbackInfo ci) {
        if (subtitle != null) {
            KnockDetector.inspectMessage(subtitle.getString());
        }
    }
}
