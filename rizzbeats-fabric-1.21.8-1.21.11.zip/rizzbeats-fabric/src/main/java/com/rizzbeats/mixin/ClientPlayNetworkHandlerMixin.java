package com.rizzbeats.mixin;

import com.rizzbeats.fx.HitSoundManager;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onPlaySound", at = @At("HEAD"))
    private void rizzbeats$onPlaySound(PlaySoundS2CPacket packet, CallbackInfo ci) {
        if (packet != null && packet.getSound() != null && packet.getSound().value() != null) {
            String path = packet.getSound().value().id().getPath();
            HitSoundManager.onProjectileOrGunHitSoundPacket(path);
        }
    }
}
