package com.rizzbeats.audio;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rizzbeats.RizzBeatsClient;
import com.rizzbeats.config.RizzConfig;
import com.rizzbeats.lyrics.LyricsManager;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * Plays MP3/WAV audio from:
 * 1) Direct audio links (.mp3, .wav, internet streams)
 * 2) YouTube / SoundCloud / free links (via system yt-dlp + ffmpeg if available)
 * 3) Song name search (via yt-dlp if installed, or instant zero-setup iTunes Search API)
 * 4) Local files inside config/rizzbeats/music/
 */
public class MusicPlayerManager {
    public record TrackInfo(String query, String displayTitle, String streamUrl, boolean isLocalFile) {}

    private static final MusicPlayerManager INSTANCE = new MusicPlayerManager();
    private final HttpClient httpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .followRedirects(HttpClient.Redirect.ALWAYS)
        .build();

    private final List<TrackInfo> history = new ArrayList<>();
    private int currentIndex = -1;

    private volatile boolean playing = false;
    private volatile boolean paused = false;
    private volatile boolean stopRequested = false;
    private volatile String currentTitle = "Tidak ada lagu diputar";
    private volatile String statusText = "Idle";
    private volatile long elapsedMs = 0L;

    private Thread playbackThread;
    private SourceDataLine activeLine;

    public static MusicPlayerManager getInstance() {
        return INSTANCE;
    }

    public boolean isPlaying() {
        return playing && !paused;
    }

    public boolean isPaused() {
        return playing && paused;
    }

    public String getCurrentTitle() {
        return currentTitle;
    }

    public String getStatusText() {
        return statusText;
    }

    public long getElapsedMs() {
        return elapsedMs;
    }

    public void playFromInput(String rawInput) {
        if (rawInput == null || rawInput.isBlank()) return;
        String input = rawInput.trim();
        stop();
        statusText = "Memuat: " + input;
        currentTitle = input;

        RizzConfig cfg = RizzConfig.get();
        if (!cfg.recentQueries.contains(input)) {
            cfg.recentQueries.add(0, input);
            if (cfg.recentQueries.size() > 20) {
                cfg.recentQueries.remove(cfg.recentQueries.size() - 1);
            }
            RizzConfig.save();
        }

        Thread.ofVirtual().start(() -> {
            TrackInfo resolved = resolveInput(input);
            if (resolved == null) {
                statusText = "Gagal memuat lagu / link tidak didukung";
                return;
            }
            synchronized (history) {
                history.add(resolved);
                currentIndex = history.size() - 1;
            }
            startTrack(resolved);
        });
    }

    public void togglePause() {
        if (!playing) return;
        paused = !paused;
        statusText = paused ? "Paused" : "Playing";
    }

    public void nextTrack() {
        synchronized (history) {
            if (history.isEmpty()) return;
            currentIndex = (currentIndex + 1) % history.size();
            TrackInfo next = history.get(currentIndex);
            startTrack(next);
        }
    }

    public void previousTrack() {
        synchronized (history) {
            if (history.isEmpty()) return;
            currentIndex = (currentIndex - 1 + history.size()) % history.size();
            TrackInfo prev = history.get(currentIndex);
            startTrack(prev);
        }
    }

    public void adjustVolume(float delta) {
        RizzConfig cfg = RizzConfig.get();
        cfg.musicVolume = Math.max(0.0f, Math.min(1.0f, cfg.musicVolume + delta));
        RizzConfig.save();
        applyVolumeToLine(activeLine, cfg.musicVolume);
    }

    public void setVolume(float vol) {
        RizzConfig cfg = RizzConfig.get();
        cfg.musicVolume = Math.max(0.0f, Math.min(1.0f, vol));
        applyVolumeToLine(activeLine, cfg.musicVolume);
    }

    public synchronized void stop() {
        stopRequested = true;
        playing = false;
        paused = false;
        elapsedMs = 0L;
        if (activeLine != null) {
            try {
                activeLine.stop();
                activeLine.close();
            } catch (Exception ignored) {}
            activeLine = null;
        }
        if (playbackThread != null && playbackThread.isAlive()) {
            playbackThread.interrupt();
        }
        statusText = "Stopped";
    }

    private void startTrack(TrackInfo track) {
        stop();
        stopRequested = false;
        playing = true;
        paused = false;
        elapsedMs = 0L;
        currentTitle = track.displayTitle();
        statusText = "Playing";

        // Fetch synced lyrics for top-screen HUD
        LyricsManager.getInstance().fetchLyricsAsync(track.displayTitle());

        playbackThread = new Thread(() -> {
            try {
                if (track.streamUrl().toLowerCase().endsWith(".wav")) {
                    playWavStream(track);
                } else {
                    playMp3Stream(track);
                }
            } catch (Exception e) {
                if (!stopRequested) {
                    RizzBeatsClient.LOGGER.error("Playback error: {}", e.getMessage());
                    statusText = "Error: " + e.getMessage();
                }
            } finally {
                playing = false;
                if (!stopRequested) {
                    statusText = "Selesai";
                }
            }
        }, "RizzBeats-AudioThread");
        playbackThread.setDaemon(true);
        playbackThread.start();
    }

    private TrackInfo resolveInput(String input) {
        // 1. Check local file in config/rizzbeats/music/
        Path localPath = RizzConfig.CUSTOM_MUSIC_DIR.resolve(input);
        if (Files.exists(localPath)) {
            String title = input.replaceAll("\\.(mp3|wav)$", "");
            return new TrackInfo(input, title, localPath.toAbsolutePath().toString(), true);
        }

        // 2. Direct audio URL (.mp3 / .wav)
        boolean isUrl = input.startsWith("http://") || input.startsWith("https://");
        if (isUrl && (input.toLowerCase().contains(".mp3") || input.toLowerCase().contains(".wav"))) {
            String fallbackTitle = input.substring(input.lastIndexOf('/') + 1).replaceAll("\\?.*", "");
            return new TrackInfo(input, fallbackTitle, input, false);
        }

        // 3. Try yt-dlp for YouTube/SoundCloud URLs or full-track song name search (if yt-dlp is installed on user's OS)
        TrackInfo ytResult = tryResolveWithYtDlp(input, isUrl);
        if (ytResult != null) {
            return ytResult;
        }

        // 4. Direct HTTP stream fallback if it's a URL
        if (isUrl) {
            return new TrackInfo(input, "Web Stream", input, false);
        }

        // 5. Instant zero-setup Song Name Search via public iTunes API
        return resolveViaItunesApi(input);
    }

    private TrackInfo tryResolveWithYtDlp(String input, boolean isUrl) {
        try {
            String query = isUrl ? input : "ytsearch1:" + input;
            ProcessBuilder pb = new ProcessBuilder(
                "yt-dlp", "--no-playlist", "-f", "bestaudio[ext=mp3]/bestaudio",
                "--print", "%(title)s", "--print", "%(url)s", query
            );
            pb.redirectErrorStream(false);
            Process p = pb.start();
            String output = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
            int code = p.waitFor();
            if (code == 0 && !output.isEmpty()) {
                String[] lines = output.split("\\R");
                if (lines.length >= 2) {
                    return new TrackInfo(input, lines[0].trim(), lines[1].trim(), false);
                }
            }
        } catch (Exception ignored) {
            // yt-dlp not installed; silently fall back to iTunes API / direct stream
        }
        return null;
    }

    private TrackInfo resolveViaItunesApi(String songName) {
        try {
            String encoded = URLEncoder.encode(songName, StandardCharsets.UTF_8);
            URI uri = URI.create("https://itunes.apple.com/search?term=" + encoded + "&media=music&limit=1");
            HttpRequest req = HttpRequest.newBuilder(uri)
                .timeout(Duration.ofSeconds(10))
                .GET()
                .build();
            HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) {
                JsonObject root = JsonParser.parseString(resp.body()).getAsJsonObject();
                JsonArray results = root.getAsJsonArray("results");
                if (results != null && !results.isEmpty()) {
                    JsonObject track = results.get(0).getAsJsonObject();
                    String title = track.has("trackName") ? track.get("trackName").getAsString() : songName;
                    String artist = track.has("artistName") ? track.get("artistName").getAsString() : "";
                    String previewUrl = track.has("previewUrl") ? track.get("previewUrl").getAsString() : null;
                    if (previewUrl != null) {
                        String fullTitle = artist.isBlank() ? title : title + " - " + artist;
                        return new TrackInfo(songName, fullTitle, previewUrl, false);
                    }
                }
            }
        } catch (Exception e) {
            RizzBeatsClient.LOGGER.warn("iTunes search failed: {}", e.getMessage());
        }
        return null;
    }

    private InputStream openTrackStream(TrackInfo track) throws Exception {
        if (track.isLocalFile()) {
            return new BufferedInputStream(Files.newInputStream(Path.of(track.streamUrl())));
        }
        HttpURLConnection conn = (HttpURLConnection) URI.create(track.streamUrl()).toURL().openConnection();
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 RizzBeatsFabric/1.0");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        return new BufferedInputStream(conn.getInputStream());
    }

    private void playMp3Stream(TrackInfo track) throws Exception {
        try (InputStream in = openTrackStream(track)) {
            Bitstream bitstream = new Bitstream(in);
            Decoder decoder = new Decoder();
            SourceDataLine line = null;

            Header header;
            while (!stopRequested && (header = bitstream.readFrame()) != null) {
                while (paused && !stopRequested) {
                    Thread.sleep(50);
                }
                if (stopRequested) break;

                SampleBuffer output = (SampleBuffer) decoder.decodeFrame(header, bitstream);
                if (line == null) {
                    AudioFormat format = new AudioFormat(
                        output.getSampleFrequency(),
                        16,
                        output.getChannelCount(),
                        true,
                        false
                    );
                    DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
                    line = (SourceDataLine) AudioSystem.getLine(info);
                    line.open(format);
                    applyVolumeToLine(line, RizzConfig.get().musicVolume);
                    line.start();
                    activeLine = line;
                }

                short[] pcm = output.getBuffer();
                int len = output.getBufferLength();
                byte[] bytes = new byte[len * 2];
                for (int i = 0; i < len; i++) {
                    short s = pcm[i];
                    bytes[i * 2] = (byte) (s & 0xFF);
                    bytes[i * 2 + 1] = (byte) ((s >>> 8) & 0xFF);
                }
                line.write(bytes, 0, bytes.length);

                float frameDurationMs = header.ms_per_frame();
                elapsedMs += (long) frameDurationMs;

                bitstream.closeFrame();
            }

            if (line != null) {
                line.drain();
                line.close();
            }
            bitstream.close();
        }
    }

    private void playWavStream(TrackInfo track) throws Exception {
        try (InputStream raw = openTrackStream(track);
             AudioInputStream ais = AudioSystem.getAudioInputStream(raw)) {
            AudioFormat format = ais.getFormat();
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
            line.open(format);
            applyVolumeToLine(line, RizzConfig.get().musicVolume);
            line.start();
            activeLine = line;

            byte[] buffer = new byte[4096];
            int bytesRead;
            double bytesPerMs = (format.getFrameRate() * format.getFrameSize()) / 1000.0;

            while (!stopRequested && (bytesRead = ais.read(buffer, 0, buffer.length)) != -1) {
                while (paused && !stopRequested) {
                    Thread.sleep(50);
                }
                if (stopRequested) break;

                line.write(buffer, 0, bytesRead);
                if (bytesPerMs > 0) {
                    elapsedMs += (long) (bytesRead / bytesPerMs);
                }
            }
            line.drain();
            line.close();
        }
    }

    private void applyVolumeToLine(SourceDataLine line, float volume) {
        if (line == null || !line.isOpen()) return;
        try {
            if (line.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gain = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
                float clamped = Math.max(0.0001f, Math.min(1.0f, volume));
                float dB = (float) (20.0 * Math.log10(clamped));
                gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB)));
            }
        } catch (Exception ignored) {}
    }
}
