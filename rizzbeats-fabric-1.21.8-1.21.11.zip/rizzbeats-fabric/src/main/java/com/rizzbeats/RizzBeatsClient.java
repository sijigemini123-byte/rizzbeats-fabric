package com.rizzbeats;

import com.rizzbeats.audio.MusicPlayerManager;
import com.rizzbeats.config.RizzConfig;
import com.rizzbeats.fx.HitSoundManager;
import com.rizzbeats.fx.KnockDetector;
import com.rizzbeats.hud.LyricsHudOverlay;
import com.rizzbeats.input.RizzKeybinds;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RizzBeatsClient implements ClientModInitializer {
    public static final String MOD_ID = "rizzbeats";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing RizzBeats & HitFX for Fabric 1.21.8-1.21.11");

        // Load config & prepare custom folders
        RizzConfig.load();

        // Register configurable keybinds
        RizzKeybinds.register();

        // Register top-screen synced lyrics HUD (Fabric 1.21.6 - 1.21.11 HudElementRegistry)
        HudElementRegistry.addLast(
            Identifier.of(MOD_ID, "lyrics_hud"),
            LyricsHudOverlay::render
        );

        // Register client tick handler for keybind actions
        ClientTickEvents.END_CLIENT_TICK.register(RizzKeybinds::onClientTick);

        // Register melee hit sound listener
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient()) {
                HitSoundManager.onMeleeAttack(entity);
            }
            return ActionResult.PASS;
        });

        // Register RizzCity chat & actionbar knock detector
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            KnockDetector.inspectMessage(message.getString());
        });

        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            KnockDetector.inspectMessage(message.getString());
        });

        // Clean shutdown hook for audio threads
        Runtime.getRuntime().addShutdownHook(new Thread(MusicPlayerManager.getInstance()::stop));
    }
}
