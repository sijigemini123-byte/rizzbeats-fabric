package com.rizzbeats.lyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rizzbeats.RizzBeatsClient;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LyricsManager {
    public record LyricLine(long timeMs, String text) {}

    private static final LyricsManager INSTANCE = new LyricsManager();
    private static final Pattern LRC_LINE_PATTERN = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\](.*)");
    private final HttpClient httpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(8))
        .build();

    private volatile List<LyricLine> currentLyrics = List.of();
    private volatile String statusMessage = "";

    public static LyricsManager getInstance() {
        return INSTANCE;
    }

    public void clear() {
        currentLyrics = List.of();
        statusMessage = "";
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public boolean hasLyrics() {
        return !currentLyrics.isEmpty();
    }

    public void fetchLyricsAsync(String trackQuery) {
        clear();
        if (trackQuery == null || trackQuery.isBlank()) return;
        statusMessage = "Mencari lirik...";

        Thread.ofVirtual().start(() -> {
            try {
                String encoded = URLEncoder.encode(trackQuery.trim(), StandardCharsets.UTF_8);
                URI uri = URI.create("https://lrclib.net/api/search?q=" + encoded);
                HttpRequest req = HttpRequest.newBuilder(uri)
                    .timeout(Duration.ofSeconds(10))
                    .header("User-Agent", "RizzBeatsFabricMod/1.0")
                    .GET()
                    .build();

                HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
                if (resp.statusCode() != 200) {
                    statusMessage = "Lirik tidak ditemukan";
                    return;
                }

                JsonArray arr = JsonParser.parseString(resp.body()).getAsJsonArray();
                String bestSynced = null;
                String fallbackPlain = null;

                for (JsonElement el : arr) {
                    JsonObject obj = el.getAsJsonObject();
                    if (obj.has("syncedLyrics") && !obj.get("syncedLyrics").isJsonNull()) {
                        String synced = obj.get("syncedLyrics").getAsString();
                        if (!synced.isBlank()) {
                            bestSynced = synced;
                            break;
                        }
                    }
                    if (fallbackPlain == null && obj.has("plainLyrics") && !obj.get("plainLyrics").isJsonNull()) {
                        fallbackPlain = obj.get("plainLyrics").getAsString();
                    }
                }

                if (bestSynced != null) {
                    List<LyricLine> parsed = parseLrc(bestSynced);
                    if (!parsed.isEmpty()) {
                        currentLyrics = parsed;
                        statusMessage = "";
                        return;
                    }
                }

                if (fallbackPlain != null && !fallbackPlain.isBlank()) {
                    // Spread plain lyrics every 3.5 seconds as an approximation
                    List<LyricLine> approx = new ArrayList<>();
                    long t = 2000L;
                    for (String line : fallbackPlain.split("\\R")) {
                        String trimmed = line.trim();
                        if (!trimmed.isEmpty()) {
                            approx.add(new LyricLine(t, trimmed));
                            t += 3500L;
                        }
                    }
                    currentLyrics = approx;
                    statusMessage = "";
                } else {
                    statusMessage = "Lirik tidak tersedia";
                }
            } catch (Exception e) {
                RizzBeatsClient.LOGGER.warn("LRCLIB lyrics fetch failed: {}", e.getMessage());
                statusMessage = "Gagal memuat lirik";
            }
        });
    }

    private List<LyricLine> parseLrc(String lrc) {
        List<LyricLine> lines = new ArrayList<>();
        for (String rawLine : lrc.split("\\R")) {
            Matcher m = LRC_LINE_PATTERN.matcher(rawLine.trim());
            if (m.find()) {
                long mins = Long.parseLong(m.group(1));
                long secs = Long.parseLong(m.group(2));
                String fracStr = m.group(3);
                long millis = 0;
                if (fracStr != null) {
                    if (fracStr.length() == 1) millis = Long.parseLong(fracStr) * 100;
                    else if (fracStr.length() == 2) millis = Long.parseLong(fracStr) * 10;
                    else millis = Long.parseLong(fracStr.substring(0, 3));
                }
                String text = m.group(4).trim();
                if (!text.isEmpty()) {
                    lines.add(new LyricLine((mins * 60 + secs) * 1000 + millis, text));
                }
            }
        }
        lines.sort(Comparator.comparingLong(LyricLine::timeMs));
        return lines;
    }

    public String getCurrentLine(long elapsedMs) {
        List<LyricLine> list = currentLyrics;
        if (list.isEmpty()) return "";
        String active = "";
        for (LyricLine line : list) {
            if (line.timeMs() <= elapsedMs) {
                active = line.text();
            } else {
                break;
            }
        }
        return active;
    }

    public String getNextLine(long elapsedMs) {
        List<LyricLine> list = currentLyrics;
        if (list.isEmpty()) return "";
        for (LyricLine line : list) {
            if (line.timeMs() > elapsedMs) {
                return line.text();
            }
        }
        return "";
    }
}
