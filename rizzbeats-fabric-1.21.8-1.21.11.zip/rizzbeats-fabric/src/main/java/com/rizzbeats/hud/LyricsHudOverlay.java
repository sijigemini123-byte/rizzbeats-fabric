package com.rizzbeats.hud;

import com.rizzbeats.audio.MusicPlayerManager;
import com.rizzbeats.config.RizzConfig;
import com.rizzbeats.lyrics.LyricsManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class LyricsHudOverlay {
    public static void render(DrawContext context, RenderTickCounter tickCounter) {
        RizzConfig cfg = RizzConfig.get();
        if (!cfg.showLyricsHud) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options.hudHidden) return;

        MusicPlayerManager player = MusicPlayerManager.getInstance();
        if (!player.isPlaying() && !player.isPaused()) return;

        LyricsManager lyrics = LyricsManager.getInstance();
        long elapsed = player.getElapsedMs();

        String mainLine = lyrics.getCurrentLine(elapsed);
        String subLine = cfg.showNextLyricLine ? lyrics.getNextLine(elapsed) : "";

        if (mainLine.isEmpty()) {
            String prefix = player.isPaused() ? "⏸ " : "♪ ";
            mainLine = prefix + player.getCurrentTitle();
            if (!lyrics.getStatusMessage().isEmpty()) {
                subLine = lyrics.getStatusMessage();
            }
        }

        TextRenderer tr = client.textRenderer;
        int screenWidth = context.getScaledWindowWidth();
        int centerX = screenWidth / 2;
        int topY = Math.max(2, cfg.lyricsTopY);

        int mainWidth = tr.getWidth(mainLine);
        int subWidth = subLine.isEmpty() ? 0 : tr.getWidth(subLine);
        int boxWidth = Math.max(mainWidth, subWidth) + 16;
        int boxHeight = subLine.isEmpty() ? 16 : 27;

        int left = centerX - (boxWidth / 2);
        int right = centerX + (boxWidth / 2);

        // Translucent dark pill background at the very top of the screen
        context.fill(left, topY, right, topY + boxHeight, 0x99000000);
        // Subtle neon accent bar along the top edge
        context.fill(left, topY, right, topY + 2, 0xFF38BDF8);

        // Primary lyric line (bright gold/white)
        context.drawCenteredTextWithShadow(tr, mainLine, centerX, topY + 4, 0xFFFDE047);

        // Secondary upcoming lyric line (soft light gray)
        if (!subLine.isEmpty()) {
            context.drawCenteredTextWithShadow(tr, subLine, centerX, topY + 15, 0xFFB0B8C4);
        }
    }
}
