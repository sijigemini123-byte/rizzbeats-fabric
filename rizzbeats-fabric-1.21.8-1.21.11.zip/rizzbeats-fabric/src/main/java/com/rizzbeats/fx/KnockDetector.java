package com.rizzbeats.fx;

import com.rizzbeats.config.RizzConfig;

import java.util.List;

/**
 * Detects knockdown notifications on RizzCity (via chat, actionbar overlay, or title/subtitle)
 * and plays the configured "Done" sound effect.
 */
public class KnockDetector {
    private static long lastKnockSoundMs = 0L;
    private static final long KNOCK_COOLDOWN_MS = 1200L;

    public static void inspectMessage(String rawText) {
        RizzConfig cfg = RizzConfig.get();
        if (!cfg.knockSoundEnabled || rawText == null || rawText.isBlank()) return;

        // Strip Minecraft formatting codes (§a, §l, etc.)
        String cleaned = rawText.replaceAll("§[0-9a-fk-orA-FK-OR]", "").toLowerCase();
        List<String> keywords = cfg.getKnockKeywordList();

        for (String kw : keywords) {
            if (cleaned.contains(kw)) {
                long now = System.currentTimeMillis();
                if (now - lastKnockSoundMs >= KNOCK_COOLDOWN_MS) {
                    lastKnockSoundMs = now;
                    HitSoundManager.playDoneSound();
                }
                return;
            }
        }
    }
}
