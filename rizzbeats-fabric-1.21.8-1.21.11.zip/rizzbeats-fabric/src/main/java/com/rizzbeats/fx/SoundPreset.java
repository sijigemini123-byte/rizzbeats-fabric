package com.rizzbeats.fx;

import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public enum SoundPreset {
    PLING_HITMARKER("Pling Hitmarker", SoundEvents.BLOCK_NOTE_BLOCK_PLING.value()),
    BELL_CHIME("Bell Chime", SoundEvents.BLOCK_NOTE_BLOCK_BELL.value()),
    XP_ORB("XP Orb Ding", SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP),
    BIT_CRISP("8-Bit Crisp", SoundEvents.BLOCK_NOTE_BLOCK_BIT.value()),
    ARROW_DING("Arrow Ding", SoundEvents.ENTITY_ARROW_HIT_PLAYER),
    ANVIL_CLANK("Anvil Clank", SoundEvents.BLOCK_ANVIL_LAND),
    GLASS_SHATTER("Glass Shatter", SoundEvents.BLOCK_GLASS_BREAK),
    AMETHYST_CHIME("Amethyst Chime", SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME),
    LEVEL_UP_DONE("Level Up (Done)", SoundEvents.ENTITY_PLAYER_LEVELUP),
    TRIDENT_THUNDER("Trident Thunder", SoundEvents.ITEM_TRIDENT_THUNDER.value()),
    BLAZE_CRISP("Blaze Crisp", SoundEvents.ENTITY_BLAZE_SHOOT),
    CUSTOM_WAV("Custom WAV (config/rizzbeats/sounds/)", null);

    private final String displayName;
    private final SoundEvent soundEvent;

    SoundPreset(String displayName, SoundEvent soundEvent) {
        this.displayName = displayName;
        this.soundEvent = soundEvent;
    }

    public String getDisplayName() {
        return displayName;
    }

    public SoundEvent getSoundEvent() {
        return soundEvent;
    }

    public SoundPreset next() {
        SoundPreset[] vals = values();
        return vals[(this.ordinal() + 1) % vals.length];
    }

    public static SoundPreset fromName(String name, SoundPreset fallback) {
        if (name == null) return fallback;
        try {
            return SoundPreset.valueOf(name);
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
