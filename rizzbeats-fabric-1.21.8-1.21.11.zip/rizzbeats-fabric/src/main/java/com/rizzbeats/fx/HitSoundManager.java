package com.rizzbeats.fx;

import com.rizzbeats.RizzBeatsClient;
import com.rizzbeats.config.RizzConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HitSoundManager {
    private static final ExecutorService WAV_EXECUTOR = Executors.newCachedThreadPool();
    private static long lastHitSoundMs = 0L;
    private static final long HIT_COOLDOWN_MS = 75L;

    public static void onMeleeAttack(Entity target) {
        RizzConfig cfg = RizzConfig.get();
        if (!cfg.hitSoundEnabled || target == null) return;
        if (cfg.hitPlayersOnly && !(target instanceof PlayerEntity)) return;
        if (!(target instanceof LivingEntity)) return;

        triggerHitSound();
    }

    public static void onProjectileOrGunHitSoundPacket(String soundIdPath) {
        RizzConfig cfg = RizzConfig.get();
        if (!cfg.hitSoundEnabled || soundIdPath == null) return;

        // Matches vanilla arrow hit, critical hit, or common server hitmarker sounds
        if (soundIdPath.contains("arrow.hit_player")
            || soundIdPath.contains("player.attack.crit")
            || soundIdPath.contains("player.attack.strong")
            || soundIdPath.contains("hitmarker")) {
            triggerHitSound();
        }
    }

    public static void triggerHitSound() {
        long now = System.currentTimeMillis();
        if (now - lastHitSoundMs < HIT_COOLDOWN_MS) return;
        lastHitSoundMs = now;

        RizzConfig cfg = RizzConfig.get();
        playPreset(cfg.getHitPreset(), cfg.hitSoundVolume, cfg.hitSoundPitch, "hit.wav");
    }

    public static void playTestHitSound() {
        RizzConfig cfg = RizzConfig.get();
        playPreset(cfg.getHitPreset(), cfg.hitSoundVolume, cfg.hitSoundPitch, "hit.wav");
    }

    public static void playDoneSound() {
        RizzConfig cfg = RizzConfig.get();
        playPreset(cfg.getKnockPreset(), cfg.knockSoundVolume, cfg.knockSoundPitch, "done.wav");
    }

    public static void playPreset(SoundPreset preset, float volume, float pitch, String customWavName) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;

        if (preset == SoundPreset.CUSTOM_WAV) {
            Path wavFile = RizzConfig.CUSTOM_SOUNDS_DIR.resolve(customWavName);
            if (Files.exists(wavFile)) {
                playLocalWav(wavFile, volume);
                return;
            } else {
                // Fallback to pling if user hasn't dropped a custom wav yet
                preset = SoundPreset.PLING_HITMARKER;
            }
        }

        final SoundPreset finalPreset = preset;
        client.execute(() -> {
            if (client.getSoundManager() != null && finalPreset.getSoundEvent() != null) {
                client.getSoundManager().play(
                    PositionedSoundInstance.master(finalPreset.getSoundEvent(), pitch, volume)
                );
            }
        });
    }

    private static void playLocalWav(Path wavPath, float volume) {
        WAV_EXECUTOR.submit(() -> {
            try (AudioInputStream ais = AudioSystem.getAudioInputStream(wavPath.toFile())) {
                Clip clip = AudioSystem.getClip();
                clip.open(ais);
                if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    float clamped = Math.max(0.001f, Math.min(1.0f, volume));
                    float dB = (float) (20.0 * Math.log10(clamped));
                    gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB)));
                }
                clip.start();
            } catch (Exception e) {
                RizzBeatsClient.LOGGER.warn("Failed to play custom WAV {}: {}", wavPath.getFileName(), e.getMessage());
            }
        });
    }
}
