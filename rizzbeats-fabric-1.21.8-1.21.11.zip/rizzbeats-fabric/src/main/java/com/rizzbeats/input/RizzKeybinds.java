package com.rizzbeats.input;

import com.rizzbeats.audio.MusicPlayerManager;
import com.rizzbeats.gui.RizzBeatsScreen;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class RizzKeybinds {
    private static final String CATEGORY = "category.rizzbeats.controls";

    public static KeyBinding openGuiKey;
    public static KeyBinding playPauseKey;
    public static KeyBinding nextTrackKey;
    public static KeyBinding prevTrackKey;
    public static KeyBinding volUpKey;
    public static KeyBinding volDownKey;

    public static void register() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.rizzbeats.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, CATEGORY
        ));
        playPauseKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.rizzbeats.play_pause", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, CATEGORY
        ));
        nextTrackKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.rizzbeats.next_track", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET, CATEGORY
        ));
        prevTrackKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.rizzbeats.prev_track", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, CATEGORY
        ));
        volUpKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.rizzbeats.vol_up", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_EQUAL, CATEGORY
        ));
        volDownKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.rizzbeats.vol_down", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_MINUS, CATEGORY
        ));
    }

    public static void onClientTick(MinecraftClient client) {
        if (client == null) return;

        while (openGuiKey.wasPressed()) {
            if (client.currentScreen == null) {
                client.setScreen(new RizzBeatsScreen());
            }
        }
        while (playPauseKey.wasPressed()) {
            MusicPlayerManager.getInstance().togglePause();
        }
        while (nextTrackKey.wasPressed()) {
            MusicPlayerManager.getInstance().nextTrack();
        }
        while (prevTrackKey.wasPressed()) {
            MusicPlayerManager.getInstance().previousTrack();
        }
        while (volUpKey.wasPressed()) {
            MusicPlayerManager.getInstance().adjustVolume(0.10f);
        }
        while (volDownKey.wasPressed()) {
            MusicPlayerManager.getInstance().adjustVolume(-0.10f);
        }
    }
}
