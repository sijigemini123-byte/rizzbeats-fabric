# RizzBeats & HitFX (Fabric 1.21.8 – 1.21.11)

Mod **client-side** Fabric untuk Minecraft Java **1.21.8 sampai 1.21.11** (aman dipakai di server multiplayer seperti RizzCity tanpa perlu dipasang di sisi server).

## Fitur Utama
1. **In-Game Music Player**
   - Bisa memutar lagu dari **nama lagu** (pencarian otomatis), **link langsung** (`.mp3` / `.wav`), **link YouTube/SoundCloud** (jika `yt-dlp` terpasang di PC), atau file lokal di `.minecraft/config/rizzbeats/music/`.
   - **Keybinds lengkap** yang bisa diubah di **Options → Controls → Key Binds**:
     - `M`: Buka GUI RizzBeats & HitFX
     - `P`: Play / Pause
     - `]`: Lagu Berikutnya
     - `[`: Lagu Sebelumnya
     - `=` / `-`: Volume Naik / Turun
2. **Lirik Lagu di Bagian Paling Atas Layar**
   - Otomatis mencari lirik tersinkronisasi (`.lrc`) lewat LRCLIB dan menampilkannya di bagian atas-tengah layar.
3. **Hit & Shoot Sound Effects (12 Pilihan + Custom WAV)**
   - Memutar efek suara saat memukul (*melee*) atau menembak (*projectile/gun hit*) lawan.
   - Bisa pilih suara, atur Volume & Pitch, serta tes langsung dari tab **Hit / Shoot FX**.
   - Mendukung file suara kustom: taruh file `hit.wav` di `.minecraft/config/rizzbeats/sounds/hit.wav`.
4. **RizzCity Knock "Done" Sound Effect**
   - Mendeteksi notifikasi knock/pingsan/tumbang dari chat, actionbar, maupun title/subtitle server RizzCity dan langsung memutar efek suara **"Done"**.
   - Kata kunci deteksi bisa kamu ubah langsung di tab **RizzCity Knock** agar 100% sesuai format teks server RizzCity.
   - Mendukung file suara kustom: taruh file `done.wav` di `.minecraft/config/rizzbeats/sounds/done.wav`.

## Cara Build Menjadi File `.jar`
Pastikan sudah terpasang **Java 21 (JDK 21)** dan **Gradle** (atau buka foldernya di IntelliJ IDEA):

```bash
gradle build
```

File `.jar` hasil build akan muncul di folder `build/libs/rizzbeats-fabric-1.0.0.jar`. Salin file tersebut bersama **Fabric API** ke folder `.minecraft/mods/`.
